
# Make changes from MAP then run SIR


# SIR


# For each parameter set in samp, calculate the log-likelihood
n_samples <- 10000
uncalib_samples <- sample_prior(n_samples)
v_llik_samps <- rep(NA,n_samples) #Pre-allocate vector

library(progress)
pb <- progress_bar$new(
  format = "  downloading [:bar] :percent :elapsed eta: :eta",
  total = n_samples, clear = FALSE, width= 60)

for(i in 1:n_samples){
  pb$tick()
  Sys.sleep(1 / n_samples)
  
  v_llik_samps[i] <- suppressMessages((l_likelihood(uncalib_samples[i, ])))
  
  if(i/100==round(i/100,0)) { 
    cat('\r',paste(i/n_samples*100,"% done",sep="")) 
  } 
}

lik_samps <- exp(v_llik_samps - max(v_llik_samps))

m_resamples <- uncalib_samples[sample(length(lik_samps),
                                      size = length(lik_samps), 
                                      prob = lik_samps,
                                      replace=TRUE),]

saveRDS(m_resamples, file = "calib_samples_sir_rounda3.RDS")
#Calculate the number of unique parameter sets
SIR_unique_sets <- nrow(unique(m_resamples))
SIR_unique_sets


m_prev_rx_use <- matrix(0, nrow = n_samples, ncol = 4,
                        dimnames = list(samp = 1:n_samples,
                                        year = c("2015", "2016", "2017", "2018")))

m_deaths <- matrix(0, nrow = n_samples, ncol = 5,
                   dimnames = list(samp = 1:n_samples,
                                   year = c("2016", "2017", "2018", "2019", "2020")))
m_od_deaths <- matrix(0, nrow = n_samples, ncol = 6,
                      dimnames = list(samp = 1:n_samples,
                                      year = c("2016", "2017", "2018", "2019",
                                               "2020", "2021")))
m_cancer <- matrix(0, nrow = n_samples, ncol = 4,
                   dimnames = list(samp = 1:n_samples,
                                   year = c("2015","2016", "2017", "2018")))
m_oat <- matrix(0, nrow = n_samples, ncol = 4,
                dimnames = list(samp = 1:n_samples,
                                year = c("2018", "2019", "2020","2021")))

pb <- progress_bar$new(
  format = "  downloading [:bar] :percent :elapsed eta: :eta",
  total = nrow(m_resamples), clear = FALSE, width= 60)

for (j in 1:nrow(m_resamples)){
  
  pb$tick()
  Sys.sleep(1 / nrow(m_resamples))
  
  calibmod <- suppressWarnings(suppressMessages(mod_calib(as.numeric(m_resamples[j, ]))))
  
  
  for (i in 1:length(2016:2020)){
    yr <- 2015 + i
    m_deaths[j, i] <- calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr &
                                                              year_mon_cycle_tbl$mon == 12] + 1,
                                   "BO_DEATH"] -
      calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr - 1 &
                                              year_mon_cycle_tbl$mon == 12] + 1,
                   "BO_DEATH"]
  }
  
  for (i in 1:length(2016:2021)){
    yr <- 2015 + i 
    m_od_deaths[j, i] <- calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr &
                                                                 year_mon_cycle_tbl$mon == 12] + 1,
                                      "BO_OD_DEATH"] -
      calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr - 1 &
                                              year_mon_cycle_tbl$mon == 12] + 1,
                   "BO_OD_DEATH"]
  }
  
  # Calculate prev
  
  prop_opioids_rx <- data.frame(matrix(NA, byrow = T, nrow = 12, ncol = length(2015:2018),
                                       list(NULL, paste0("prop_opioids_rx_", str_sub(2015:2018, 3, 4)))))
  
  tot_pop_tbl <- data.frame(matrix(NA, byrow = T, nrow = 12, ncol = length(2015:2018),
                                   list(NULL, paste0("tot_pop_", str_sub(2015:2018, 3, 4)))))
  
  for (i in 1:length(2015:2018)) {
    
    yr <- 2014 + i
    prop_opioids_rx[, i] <- assign(
      paste0("prop_opioids_rx_", str_sub(yr, 3, 4)),
      rowSums(calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr] + 1,
                           c("BPO_ACUTE", "BPO_CHRONIC", "BPO_CANCER",
                             "BPO_OTHER", "BPO_PALLIATIVE")]) /
        rowSums(calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr] + 1,])
      
    )
    
    tot_pop_tbl[, i] <- assign(
      paste0("tot_pop_", str_sub(yr, 3, 4)),
      rowSums(calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr] + 1,])
    )
  }
  
  prop_opioids_rx <- prop_opioids_rx %>% 
    pivot_longer(1:4, names_to = "grp", values_to = "target_val") %>% 
    arrange(grp) %>% 
    mutate(year = rep(2015:2018, each = 12),
           year_mon = paste(year, month.abb[1:12], sep = "_")) %>% 
    bind_cols(., tot_pop_tbl %>% 
                pivot_longer(1:4, names_to = "tot_pop", values_to = "tot_pop_val") %>% 
                arrange(tot_pop) %>% dplyr::select(-tot_pop)) %>% 
    group_by(year) %>% 
    summarise(target_val = weighted.mean(target_val, tot_pop_val)) %>% 
    ungroup()
  
  m_prev_rx_use[j, ] <- prop_opioids_rx$target_val
  
  # calculate cancer
  
  for (i in 1:length(2015:2018)){
    yr <- 2014 + i
    m_cancer[j, i] <- sum(calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr &
                                                                  year_mon_cycle_tbl$mon == 6] + 1,
                                       c("BN_CANCER", "BPO_CANCER")])
  }
  
  # calculate oat
  for (i in 1:length(2018:2021)){
    yr <- 2017 + i 
    m_oat[j, i] <- sum(calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr &
                                                               year_mon_cycle_tbl$mon == 6] + 1,
                                    c("BS_OAT_INI", "BS_OAT_MAINT", "BR_OAT_INI", "BR_OAT_MAINT")])
    
  }
  
  
}

saveRDS(m_prev_rx_use, file = "prev_outcome_data_sir_td.RDS")
saveRDS(m_od_deaths, file = "oddeath_outcome_data_sir_td.RDS")
saveRDS(m_deaths, file = "death_outcome_data_sir_td.RDS")
saveRDS(m_cancer, file = "cancer_outcome_data_sir_td.RDS")
saveRDS(m_oat, file = "oat_outcome_data_sir_td.RDS")

## sir- uncalib sample

uncalib_resamples <- uncalib_samples[sample(n_samples,
                                            size = n_samples,
                                            replace=TRUE),]
saveRDS(uncalib_resamples, file = "uncalib_sample_sir_td.RDS")

m_prev_rx_use_uncalib <- matrix(0, nrow = n_samples, ncol = 4,
                                dimnames = list(samp = 1:n_samples,
                                                year = c("2015", "2016", "2017", "2018")))

m_deaths_uncalib <- matrix(0, nrow = n_samples, ncol = 5,
                           dimnames = list(samp = 1:n_samples,
                                           year = c("2016", "2017", "2018", "2019", "2020")))


m_od_deaths_uncalib <- matrix(0, nrow = n_samples, ncol = 6,
                              dimnames = list(samp = 1:n_samples,
                                              year = c("2016", "2017", "2018", "2019",
                                                       "2020", "2021")))

m_cancer_uncalib <- matrix(0, nrow = n_samples, ncol = 4,
                           dimnames = list(samp = 1:n_samples,
                                           year = c("2015","2016", "2017", "2018")))
m_oat_uncalib <- matrix(0, nrow = n_samples, ncol = 4,
                        dimnames = list(samp = 1:n_samples,
                                        year = c("2018", "2019", "2020","2021")))


pb <- progress_bar$new(
  format = "  downloading [:bar] :percent :elapsed eta: :eta",
  total = n_samples, clear = FALSE, width= 60)

for (j in 1:nrow(uncalib_samples)){
  
  pb$tick()
  Sys.sleep(1 / nrow(uncalib_samples))
  
  calibmod <- suppressWarnings(suppressMessages(mod_calib(as.numeric(uncalib_resamples[j, ]))))
  
  
  for (i in 1:length(2016:2020)){
    yr <- 2015 + i
    m_deaths_uncalib[j, i] <- calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr &
                                                                      year_mon_cycle_tbl$mon == 12] + 1,
                                           "BO_DEATH"] -
      calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr - 1 &
                                              year_mon_cycle_tbl$mon == 12] + 1,
                   "BO_DEATH"]
  }
  
  for (i in 1:length(2016:2021)){
    yr <- 2015 + i 
    m_od_deaths_uncalib[j, i] <- calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr &
                                                                         year_mon_cycle_tbl$mon == 12] + 1,
                                              "BO_OD_DEATH"] -
      calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr - 1 &
                                              year_mon_cycle_tbl$mon == 12] + 1,
                   "BO_OD_DEATH"]
  }
  
  # Calculate prev
  
  prop_opioids_rx <- data.frame(matrix(NA, byrow = T, nrow = 12, ncol = length(2015:2018),
                                       list(NULL, paste0("prop_opioids_rx_", str_sub(2015:2018, 3, 4)))))
  
  tot_pop_tbl <- data.frame(matrix(NA, byrow = T, nrow = 12, ncol = length(2015:2018),
                                   list(NULL, paste0("tot_pop_", str_sub(2015:2018, 3, 4)))))
  
  for (i in 1:length(2015:2018)) {
    
    yr <- 2014 + i
    prop_opioids_rx[, i] <- assign(
      paste0("prop_opioids_rx_", str_sub(yr, 3, 4)),
      rowSums(calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr] + 1,
                           c("BPO_ACUTE", "BPO_CHRONIC", "BPO_CANCER",
                             "BPO_OTHER", "BPO_PALLIATIVE")]) /
        rowSums(calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr] + 1,])
      
    )
    
    tot_pop_tbl[, i] <- assign(
      paste0("tot_pop_", str_sub(yr, 3, 4)),
      rowSums(calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr] + 1,])
    )
  }
  
  prop_opioids_rx <- prop_opioids_rx %>% 
    pivot_longer(1:4, names_to = "grp", values_to = "target_val") %>% 
    arrange(grp) %>% 
    mutate(year = rep(2015:2018, each = 12),
           year_mon = paste(year, month.abb[1:12], sep = "_")) %>% 
    bind_cols(., tot_pop_tbl %>% 
                pivot_longer(1:4, names_to = "tot_pop", values_to = "tot_pop_val") %>% 
                arrange(tot_pop) %>% dplyr::select(-tot_pop)) %>% 
    group_by(year) %>% 
    summarise(target_val = weighted.mean(target_val, tot_pop_val)) %>% 
    ungroup()
  
  m_prev_rx_use_uncalib[j, ] <- prop_opioids_rx$target_val
  
  
  # calculate cancer
  
  for (i in 1:length(2015:2018)){
    yr <- 2014 + i
    m_cancer_uncalib[j, i] <- sum(calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr &
                                                                          year_mon_cycle_tbl$mon == 6] + 1,
                                               c("BN_CANCER", "BPO_CANCER")])
  }
  
  # calculate oat
  for (i in 1:length(2018:2021)){
    yr <- 2017 + i 
    m_oat_uncalib[j, i] <- sum(calibmod$m_M[year_mon_cycle_tbl$cycle[year_mon_cycle_tbl$year == yr &
                                                                       year_mon_cycle_tbl$mon == 6] + 1,
                                            c("BS_OAT_INI", "BS_OAT_MAINT", "BR_OAT_INI", "BR_OAT_MAINT")])
    
  }
  
}

saveRDS(m_prev_rx_use_uncalib, file = "prev_outcome_data_sir_uncalib_td.RDS")
saveRDS(m_od_deaths_uncalib, file = "oddeath_outcome_data_sir_uncalib_td.RDS")
saveRDS(m_deaths_uncalib, file = "death_outcome_data_sir_uncalib_td.RDS")
saveRDS(m_cancer_uncalib, file = "cancer_sir_unclaib_td.RDS")
saveRDS(m_oat_uncalib, file = "oat_sir_uncalib_td.RDS")
nrow(unique(uncalib_resamples))




